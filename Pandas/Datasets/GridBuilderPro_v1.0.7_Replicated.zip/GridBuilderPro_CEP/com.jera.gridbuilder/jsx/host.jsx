/**
 * ============================================================
 *  GRID BUILDER PRO — host.jsx  (ExtendScript backend)
 *  CEP Extension: com.jera.gridbuilder  v1.0.7
 * ============================================================
 *
 *  This file is loaded by the CSXS manifest as the ScriptPath.
 *  It exposes these global functions to the CEP panel (host.js):
 *
 *    getGridsData()
 *    gridCreate(mode, extPath, isTrial)
 *    gridUpdate(mode, extPath, gridName, isTrial)
 *    gridAdd(gridName, extPath, isTrial)
 *    gridReplace(gridName, layerIds, isTrial)
 *    gridRemoveLayers(gridName, layerIds, isTrial)
 *    gridReorder(gridName, layerIds, isTrial)
 *    gridRemove(gridName)
 *    gridRemoveAll()
 *    gridDuplicate(gridName)
 *    aeAlert(msg)
 *
 *  GRID MODES:
 *    0 = Rectangular
 *    1 = Radial
 *    2 = Spherical
 *    3 = Path
 *
 *  ARCHITECTURE:
 *    Each "grid" is:
 *      - A Null layer named "GB_<gridName>" (the master controller)
 *      - A pseudo-effect applied from the matching .ffx file
 *      - All grid member layers linked via expressions to the Null
 *      - A JSON "registry" stored as a Null comment for persistence
 * ============================================================
 */

// ─── Global registry key stored on the AE project ───────────
var GB_TAG      = "GridBuilder_";          // Null layer name prefix
var GB_COMMENT  = "__GB_REGISTRY__";       // Marker on registry Null
var GB_VERSION  = "1.0.7";

// ─── Pseudo-effect .ffx file names (per mode) ──────────────
var FFX_NAMES = {
  0: "GridRect_V102.ffx",
  1: "GridRad_V102.ffx",
  2: "GridSphere_V102.ffx",
  3: "GridPath_V102.ffx"
};

// ─── Mode names for auto-naming ─────────────────────────────
var MODE_NAMES = { 0:"Rect", 1:"Rad", 2:"Sphere", 3:"Path" };

// ════════════════════════════════════════════════════════════
//  UTILITY HELPERS
// ════════════════════════════════════════════════════════════

function aeAlert(msg) {
  alert("[Grid Builder]\n" + msg);
}

function getActiveComp() {
  var comp = app.project.activeItem;
  if (!(comp instanceof CompItem)) { aeAlert("Please open a composition first."); return null; }
  return comp;
}

function getSelectedLayers(comp) {
  var result = [];
  var sel = comp.selectedLayers;
  for (var i = 0; i < sel.length; i++) result.push(sel[i]);
  return result;
}

/** Generate a unique grid name based on existing names */
function generateGridName(comp, mode) {
  var base   = MODE_NAMES[mode] || "Grid";
  var idx    = 1;
  var names  = {};
  var grids  = getAllGridNulls(comp);
  for (var i = 0; i < grids.length; i++) {
    names[grids[i].gridName] = true;
  }
  while (names[base + "_" + idx]) idx++;
  return base + "_" + idx;
}

/** Find a layer by its GB unique ID stored as a marker comment */
function findLayerById(comp, id) {
  for (var i = 1; i <= comp.numLayers; i++) {
    var l = comp.layer(i);
    try {
      if (l.comment && l.comment.indexOf("GB_ID:" + id) > -1) return l;
    } catch(e) {}
  }
  return null;
}

/** Get/create a stable unique ID for a layer */
function ensureLayerId(layer) {
  // ID stored as "GB_ID:XXXXX" in the layer comment
  var comment = "";
  try { comment = layer.comment || ""; } catch(e) {}
  var match = comment.match(/GB_ID:([a-zA-Z0-9_]+)/);
  if (match) return match[1];
  // Generate new ID from layer index + name hash
  var id = "L" + layer.index + "_" + (Math.abs(hashStr(layer.name + layer.index)) % 100000);
  try {
    layer.comment = (comment ? comment + " " : "") + "GB_ID:" + id;
  } catch(e) {}
  return id;
}

function hashStr(s) {
  var h = 5381;
  for (var i = 0; i < s.length; i++) h = ((h << 5) + h) ^ s.charCodeAt(i);
  return h;
}

/** Find the Null layer that controls a named grid */
function findGridNull(comp, gridName) {
  for (var i = 1; i <= comp.numLayers; i++) {
    var l = comp.layer(i);
    if (l.name === GB_TAG + gridName && l.nullLayer) return l;
  }
  return null;
}

/** Read grid membership list from Null comment */
function readGridMeta(nullLayer) {
  try {
    var comment = nullLayer.comment || "{}";
    var meta = JSON.parse(comment);
    if (!meta.members) meta.members = [];
    if (!meta.mode)    meta.mode    = 0;
    if (!meta.name)    meta.name    = nullLayer.name.replace(GB_TAG, "");
    return meta;
  } catch(e) {
    return { members: [], mode: 0, name: nullLayer.name.replace(GB_TAG, "") };
  }
}

/** Write grid metadata back to Null comment */
function writeGridMeta(nullLayer, meta) {
  try { nullLayer.comment = JSON.stringify(meta); } catch(e) {}
}

/** Get all grid Null layers in comp */
function getAllGridNulls(comp) {
  var result = [];
  for (var i = 1; i <= comp.numLayers; i++) {
    var l = comp.layer(i);
    if (l.nullLayer && l.name.indexOf(GB_TAG) === 0) {
      var meta = readGridMeta(l);
      result.push({ layer: l, gridName: meta.name, meta: meta });
    }
  }
  return result;
}

// ════════════════════════════════════════════════════════════
//  .FFX PSEUDO-EFFECT APPLICATION
// ════════════════════════════════════════════════════════════

/**
 * Apply the correct .ffx preset to the null layer.
 * The .ffx files live in the extension's /src/ folder.
 * AE's applyPreset() requires a File object pointing to the .ffx.
 */
function applyFFX(nullLayer, mode, extPath) {
  var ffxName = FFX_NAMES[mode];
  if (!ffxName) return;
  try {
    var ffxPath = extPath + "/src/" + ffxName;
    var ffxFile = new File(ffxPath);
    if (!ffxFile.exists) {
      // Try without leading /
      ffxFile = new File(ffxPath.replace(/^\//, ""));
    }
    if (ffxFile.exists) {
      nullLayer.applyPreset(ffxFile);
    } else {
      aeAlert("Cannot find preset: " + ffxPath + "\nMake sure the extension is installed correctly.");
    }
  } catch(e) {
    aeAlert("Error applying preset: " + e.toString());
  }
}

/** Remove all effects from a layer that were applied by GB */
function removeGBEffects(nullLayer) {
  // Remove effects whose name matches GB_ prefix or came from our .ffx
  var fx = nullLayer.Effects;
  for (var i = fx.numProperties; i >= 1; i--) {
    var ef = fx.property(i);
    // .ffx presets typically leave a group effect. Remove all.
    try { ef.remove(); } catch(e) {}
  }
}

// ════════════════════════════════════════════════════════════
//  EXPRESSION BUILDERS
//  All expressions read controls from the Null's pseudo-effect.
//  The .ffx preset defines exact MatchName for each control.
//  We use the control NAMES (which the .ffx sets) to reference.
// ════════════════════════════════════════════════════════════

var NULL_COMMENT_PREFIX = "GB_GRID:";

/**
 * For each grid member layer, expressions are applied to:
 *   transform.position  — grid position
 *   transform.scale     — scale variation
 *   transform.rotation  — rotation / orientation
 *
 * Expressions reference the Null by name (GB_TAG + gridName)
 * so they stay valid even if layer order changes.
 */

function makeNullRef(gridName) {
  return 'var _n = thisComp.layer("' + GB_TAG + gridName + '"); var _fx = _n.effect;';
}

// ── Helper: safely read a named effect property ──────────────
// The .ffx defines controls with specific names. We read by name.
function fxRead(name) {
  return '_fx("' + name + '")(1).value';
}

// ─────────────────────────────────────────────────────────────
//  RECTANGULAR GRID EXPRESSIONS
// ─────────────────────────────────────────────────────────────
function makeRectPositionExpr(gridName, idx, total) {
  return [
    makeNullRef(gridName),
    "var _idx   = " + idx + ";",
    "var _total = " + total + ";",
    "var _cols  = Math.max(1, Math.round(" + fxRead("Columns") + "));",
    "var _rows  = Math.ceil(_total / _cols);",
    "var _spX   = " + fxRead("Spacing X") + ";",
    "var _spY   = " + fxRead("Spacing Y") + ";",
    "var _seed  = Math.round(" + fxRead("Random Seed") + ");",
    "var _rnd   = " + fxRead("Position Randomness") + ";",
    "var _c     = _idx % _cols;",
    "var _r     = Math.floor(_idx / _cols);",
    "var _ox    = (_cols - 1) * _spX / 2;",
    "var _oy    = (_rows - 1) * _spY / 2;",
    "var _rx=0,_ry=0;",
    "if(_rnd>0){seedRandom(_seed+_idx*7,true);_rx=(random()-0.5)*2*_rnd;_ry=(random()-0.5)*2*_rnd;}",
    "var _bp = _n.transform.position.value;",
    "[_bp[0]+_c*_spX-_ox+_rx, _bp[1]+_r*_spY-_oy+_ry]"
  ].join("\n");
}

function makeRectScaleExpr(gridName, idx) {
  return [
    makeNullRef(gridName),
    "var _idx  = " + idx + ";",
    "var _base = " + fxRead("Scale") + ";",
    "var _var  = " + fxRead("Scale Randomness") + ";",
    "var _seed = Math.round(" + fxRead("Random Seed") + ")+99;",
    "seedRandom(_seed+_idx*13,true);",
    "var _r = 1+(random()-0.5)*2*(_var/100);",
    "[_base*_r, _base*_r]"
  ].join("\n");
}

function makeRectRotationExpr(gridName, idx) {
  return [
    makeNullRef(gridName),
    "var _idx  = " + idx + ";",
    "var _base = " + fxRead("Rotation") + ";",
    "var _var  = " + fxRead("Rotation Randomness") + ";",
    "var _seed = Math.round(" + fxRead("Random Seed") + ")+42;",
    "seedRandom(_seed+_idx*17,true);",
    "_base + (random()-0.5)*2*_var"
  ].join("\n");
}

// ─────────────────────────────────────────────────────────────
//  RADIAL GRID EXPRESSIONS
// ─────────────────────────────────────────────────────────────
function makeRadialPositionExpr(gridName, idx, total) {
  return [
    makeNullRef(gridName),
    "var _idx    = " + idx + ";",
    "var _total  = " + total + ";",
    "var _r      = " + fxRead("Radius") + ";",
    "var _spread = " + fxRead("Angle Spread") + ";",
    "var _start  = " + fxRead("Start Angle") + ";",
    "var _cw     = " + fxRead("Clockwise") + ";",
    "var _rnd    = " + fxRead("Position Randomness") + ";",
    "var _seed   = Math.round(" + fxRead("Random Seed") + ");",
    "var _step   = (_total>1) ? _spread/_total : 0;",
    "var _dir    = (_cw>=0.5) ? 1 : -1;",
    "var _ang    = (_start + _dir*_step*_idx) * Math.PI/180;",
    "var _rr=0;",
    "if(_rnd>0){seedRandom(_seed+_idx*7,true);_rr=(random()-0.5)*2*_rnd;}",
    "var _bp = _n.transform.position.value;",
    "[_bp[0]+Math.cos(_ang)*(_r+_rr), _bp[1]+Math.sin(_ang)*(_r+_rr)]"
  ].join("\n");
}

function makeRadialRotationExpr(gridName, idx, total, orientMode) {
  var orientCalc = (orientMode === 1)
    ? "_start + _dir*_step*_idx + 90"
    : fxRead("Rotation");
  return [
    makeNullRef(gridName),
    "var _idx    = " + idx + ";",
    "var _total  = " + total + ";",
    "var _spread = " + fxRead("Angle Spread") + ";",
    "var _start  = " + fxRead("Start Angle") + ";",
    "var _cw     = " + fxRead("Clockwise") + ";",
    "var _step   = (_total>1) ? _spread/_total : 0;",
    "var _dir    = (_cw>=0.5) ? 1 : -1;",
    orientCalc
  ].join("\n");
}

// ─────────────────────────────────────────────────────────────
//  PATH GRID EXPRESSIONS  (mode 3)
//  Path type is stored in the "Path Type" effect slider:
//    0 = Ellipse, 1 = Line, 2 = Sine Wave, 3 = Spiral
// ─────────────────────────────────────────────────────────────
function makePathPositionExpr(gridName, idx, total) {
  return [
    makeNullRef(gridName),
    "var _idx    = " + idx + ";",
    "var _total  = " + total + ";",
    "var _ptype  = Math.round(" + fxRead("Path Type") + ");",
    "var _r      = " + fxRead("Radius") + ";",
    "var _len    = " + fxRead("Path Length") + ";",
    "var _wA     = " + fxRead("Wave Amplitude") + ";",
    "var _wF     = " + fxRead("Wave Frequency") + ";",
    "var _rnd    = " + fxRead("Position Randomness") + ";",
    "var _seed   = Math.round(" + fxRead("Random Seed") + ");",
    "var _t      = (_total>1) ? _idx/(_total-1) : 0;",
    "var _bp     = _n.transform.position.value;",
    "var _px, _py;",
    "if(_ptype===1){",                                         // Line
    "  _px = _bp[0] - _len/2 + _t*_len;",
    "  _py = _bp[1];",
    "} else if(_ptype===2){",                                  // Sine Wave
    "  _px = _bp[0] - _len/2 + _t*_len;",
    "  _py = _bp[1] + Math.sin(_t*_wF*Math.PI*2)*_wA;",
    "} else if(_ptype===3){",                                  // Spiral
    "  var _ang3 = _t*_wF*Math.PI*2;",
    "  _px = _bp[0] + Math.cos(_ang3)*(_r*_t);",
    "  _py = _bp[1] + Math.sin(_ang3)*(_r*_t);",
    "} else {",                                                // Ellipse (0)
    "  var _ta = (_total>1) ? _idx/_total : 0;",
    "  var _ang0 = _ta*Math.PI*2;",
    "  _px = _bp[0] + Math.cos(_ang0)*_r;",
    "  _py = _bp[1] + Math.sin(_ang0)*_r;",
    "}",
    "if(_rnd>0){seedRandom(_seed+_idx*7,true);_px+=(random()-0.5)*2*_rnd;_py+=(random()-0.5)*2*_rnd;}",
    "[_px, _py]"
  ].join("\n");
}

function makePathRotationExpr(gridName, idx, total) {
  return [
    makeNullRef(gridName),
    "var _idx   = " + idx + ";",
    "var _total = " + total + ";",
    "var _ptype = Math.round(" + fxRead("Path Type") + ");",
    "var _r     = " + fxRead("Radius") + ";",
    "var _len   = " + fxRead("Path Length") + ";",
    "var _wF    = " + fxRead("Wave Frequency") + ";",
    "var _wA    = " + fxRead("Wave Amplitude") + ";",
    "var _base  = " + fxRead("Rotation") + ";",
    "var _t     = (_total>1) ? _idx/(_total-1) : 0;",
    "var _ang;",
    "var _dt    = 0.001;",
    "var _t2    = Math.min(_t+_dt,1);",
    "if(_ptype===1){",
    "  _ang = 0;",
    "} else if(_ptype===2){",
    "  var _dy = Math.sin(_t2*_wF*Math.PI*2)*_wA - Math.sin(_t*_wF*Math.PI*2)*_wA;",
    "  var _dx = _t2*1 - _t*1;",
    "  _ang = Math.atan2(_dy, _dx)*180/Math.PI;",
    "} else if(_ptype===3){",
    "  _ang = _t*_wF*360 + 90;",
    "} else {",
    "  _ang = (_total>1) ? _idx/_total*360+90 : 0;",
    "}",
    "_base + _ang"
  ].join("\n");
}

// ─────────────────────────────────────────────────────────────
//  SPHERICAL GRID EXPRESSIONS  (mode 2)
//  Uses the Fibonacci sphere algorithm for uniform coverage.
// ─────────────────────────────────────────────────────────────
function makeSpherePositionExpr(gridName, idx, total) {
  return [
    makeNullRef(gridName),
    "var _idx    = " + idx + ";",
    "var _total  = " + total + ";",
    "var _r      = " + fxRead("Radius") + ";",
    "var _rnd    = " + fxRead("Position Randomness") + ";",
    "var _seed   = Math.round(" + fxRead("Random Seed") + ");",
    "var _golden = Math.PI*(3-Math.sqrt(5));",
    "var _theta  = _golden*_idx;",
    "var _phi    = Math.acos(1 - 2*(_idx+0.5)/Math.max(_total,1));",
    "var _sx     = _r*Math.sin(_phi)*Math.cos(_theta);",
    "var _sy     = _r*Math.sin(_phi)*Math.sin(_theta);",
    "var _sz     = _r*Math.cos(_phi);",
    "if(_rnd>0){seedRandom(_seed+_idx*7,true);_sx+=(random()-0.5)*2*_rnd;_sy+=(random()-0.5)*2*_rnd;_sz+=(random()-0.5)*2*_rnd;}",
    "var _bp = _n.transform.position.value;",
    "[_bp[0]+_sx, _bp[1]+_sy, _bp[2]+_sz]"
  ].join("\n");
}

// Shared scale expression used by all modes
function makeScaleExpr(gridName, idx) {
  return [
    makeNullRef(gridName),
    "var _idx  = " + idx + ";",
    "var _base = " + fxRead("Scale") + ";",
    "var _var  = " + fxRead("Scale Randomness") + ";",
    "var _seed = Math.round(" + fxRead("Random Seed") + ")+99;",
    "seedRandom(_seed+_idx*13,true);",
    "var _r = 1+(random()-0.5)*2*(_var/100);",
    "[_base*_r, _base*_r]"
  ].join("\n");
}

// ════════════════════════════════════════════════════════════
//  EXPRESSION ASSIGNMENT
// ════════════════════════════════════════════════════════════

/**
 * Apply expressions to a layer based on mode and its index
 * in the ordered member list.
 */
function applyExpressionsToMember(layer, mode, idx, total, gridName) {
  function setExpr(prop, expr) {
    if (!prop) return;
    try { prop.expression = expr; } catch(e) {}
  }

  var pos = layer.transform.position;
  var scl = layer.transform.scale;
  var rot = layer.transform.rotation;

  setExpr(scl, makeScaleExpr(gridName, idx));

  switch (mode) {
    case 0: // Rectangular
      setExpr(pos, makeRectPositionExpr(gridName, idx, total));
      setExpr(rot, makeRectRotationExpr(gridName, idx));
      break;
    case 1: // Radial
      setExpr(pos, makeRadialPositionExpr(gridName, idx, total));
      setExpr(rot, makeRadialRotationExpr(gridName, idx, total, 0));
      break;
    case 2: // Spherical
      layer.threeDLayer = true;
      setExpr(pos, makeSpherePositionExpr(gridName, idx, total));
      setExpr(rot, makeRectRotationExpr(gridName, idx)); // base rotation
      break;
    case 3: // Path
      setExpr(pos, makePathPositionExpr(gridName, idx, total));
      setExpr(rot, makePathRotationExpr(gridName, idx, total));
      break;
  }
}

/** Remove all GB expressions from a layer (when removing from grid) */
function clearExpressionsFromMember(layer) {
  function clearExpr(prop) {
    if (!prop) return;
    try { if (prop.expression !== "") prop.expression = ""; } catch(e) {}
  }
  clearExpr(layer.transform.position);
  clearExpr(layer.transform.scale);
  clearExpr(layer.transform.rotation);
  try {
    clearExpr(layer.transform.xRotation);
    clearExpr(layer.transform.yRotation);
    clearExpr(layer.transform.zRotation);
  } catch(e) {}
}

/** Re-apply all expressions for all current members of a grid */
function rebuildAllExpressions(comp, nullLayer, meta) {
  var members = meta.members;
  var total   = members.length;
  for (var i = 0; i < total; i++) {
    var layer = findLayerById(comp, members[i].id);
    if (layer) {
      applyExpressionsToMember(layer, meta.mode, i, total, meta.name);
    }
  }
}

// ════════════════════════════════════════════════════════════
//  PUBLIC API — called from host.js via evalScript
// ════════════════════════════════════════════════════════════

/**
 * getGridsData()
 * Returns a JSON string describing all grids in the active comp.
 * Shape: [{gridName, mode, layers:[{id,name,label}]}]
 */
function getGridsData() {
  var comp = getActiveComp();
  if (!comp) return "[]";

  var result  = [];
  var nulls   = getAllGridNulls(comp);

  for (var i = 0; i < nulls.length; i++) {
    var entry = nulls[i];
    var meta  = entry.meta;
    var layerInfos = [];

    for (var j = 0; j < meta.members.length; j++) {
      var memberId = meta.members[j].id;
      var layer    = findLayerById(comp, memberId);
      if (layer) {
        layerInfos.push({
          id:    memberId,
          name:  layer.name,
          label: layer.label
        });
      }
    }

    result.push({
      gridName: meta.name,
      mode:     meta.mode,
      layers:   layerInfos
    });
  }

  return JSON.stringify(result);
}

/**
 * gridCreate(mode, extPath, isTrial)
 * Creates a new grid from currently selected layers.
 */
function gridCreate(mode, extPath, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var selected = getSelectedLayers(comp);
  if (selected.length === 0) {
    aeAlert("Please select at least one layer in the timeline.");
    return;
  }

  app.beginUndoGroup("Grid Builder: Create Grid");
  try {
    var gridName = generateGridName(comp, mode);

    // 1. Create the master Null
    var nullLayer = comp.layers.addNull(comp.duration);
    nullLayer.name     = GB_TAG + gridName;
    nullLayer.label    = 12; // Purple
    nullLayer.nullLayer = true;
    nullLayer.transform.position.setValue([comp.width / 2, comp.height / 2]);
    if (mode === 2) nullLayer.threeDLayer = true;
    nullLayer.moveToBeginning();

    // 2. Apply pseudo-effect from .ffx
    applyFFX(nullLayer, mode, extPath);

    // 3. Register members
    var members = [];
    for (var i = 0; i < selected.length; i++) {
      var id = ensureLayerId(selected[i]);
      members.push({ id: id });
    }

    var meta = { name: gridName, mode: mode, members: members };
    writeGridMeta(nullLayer, meta);

    // 4. Apply expressions
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error creating grid: " + e.toString() + " (line " + e.line + ")");
  }
}

/**
 * gridUpdate(mode, extPath, gridName, isTrial)
 * Changes the grid type (mode) of an existing grid.
 */
function gridUpdate(mode, extPath, gridName, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) { aeAlert("Grid '" + gridName + "' not found."); return; }

  app.beginUndoGroup("Grid Builder: Change Mode");
  try {
    var meta = readGridMeta(nullLayer);
    meta.mode = mode;

    // Re-apply .ffx for new mode
    removeGBEffects(nullLayer);
    applyFFX(nullLayer, mode, extPath);

    // Enable/disable 3D on null
    try { nullLayer.threeDLayer = (mode === 2); } catch(e) {}

    writeGridMeta(nullLayer, meta);
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error changing mode: " + e.toString());
  }
}

/**
 * gridAdd(gridName, extPath, isTrial)
 * Adds currently selected layer(s) to an existing grid.
 * If gridName is undefined, creates a new grid.
 */
function gridAdd(gridName, extPath, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var selected = getSelectedLayers(comp);
  if (selected.length === 0) { aeAlert("Please select layers in the timeline to add."); return; }

  // If no grid yet, create one
  if (!gridName || gridName === "undefined") {
    gridCreate(0, extPath, isTrial);
    return;
  }

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) { aeAlert("Grid '" + gridName + "' not found."); return; }

  app.beginUndoGroup("Grid Builder: Add Layer");
  try {
    var meta = readGridMeta(nullLayer);

    // Check for duplicates
    var existingIds = {};
    for (var i = 0; i < meta.members.length; i++) existingIds[meta.members[i].id] = true;

    for (var j = 0; j < selected.length; j++) {
      var id = ensureLayerId(selected[j]);
      if (!existingIds[id]) {
        meta.members.push({ id: id });
        existingIds[id] = true;
      }
    }

    writeGridMeta(nullLayer, meta);
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error adding layer: " + e.toString());
  }
}

/**
 * gridReplace(gridName, layerIds, isTrial)
 * Swaps the highlighted grid positions with the currently
 * selected layers in the timeline.
 */
function gridReplace(gridName, layerIds, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) return;

  var selected = getSelectedLayers(comp);
  if (selected.length === 0) { aeAlert("Please select replacement layers in the timeline."); return; }

  app.beginUndoGroup("Grid Builder: Replace Layer");
  try {
    var meta = readGridMeta(nullLayer);

    // Build index map: id → position in members array
    var idToIdx = {};
    for (var i = 0; i < meta.members.length; i++) idToIdx[meta.members[i].id] = i;

    for (var k = 0; k < layerIds.length && k < selected.length; k++) {
      var targetId  = String(layerIds[k]);
      var newId     = ensureLayerId(selected[k]);
      if (idToIdx[targetId] !== undefined) {
        // Clear expressions from old layer
        var oldLayer = findLayerById(comp, targetId);
        if (oldLayer) clearExpressionsFromMember(oldLayer);
        // Replace in meta
        meta.members[idToIdx[targetId]] = { id: newId };
      }
    }

    writeGridMeta(nullLayer, meta);
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error replacing: " + e.toString());
  }
}

/**
 * gridRemoveLayers(gridName, layerIds, isTrial)
 * Removes specific layers from a grid (by their GB IDs).
 */
function gridRemoveLayers(gridName, layerIds, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) return;

  app.beginUndoGroup("Grid Builder: Remove Layer");
  try {
    var meta = readGridMeta(nullLayer);

    // Build a set of IDs to remove
    var removeSet = {};
    for (var k = 0; k < layerIds.length; k++) removeSet[String(layerIds[k])] = true;

    // Clear expressions from removed layers
    for (var i = 0; i < meta.members.length; i++) {
      if (removeSet[meta.members[i].id]) {
        var layer = findLayerById(comp, meta.members[i].id);
        if (layer) clearExpressionsFromMember(layer);
      }
    }

    // Filter out removed members
    var newMembers = [];
    for (var j = 0; j < meta.members.length; j++) {
      if (!removeSet[meta.members[j].id]) newMembers.push(meta.members[j]);
    }
    meta.members = newMembers;

    writeGridMeta(nullLayer, meta);
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error removing layers: " + e.toString());
  }
}

/**
 * gridReorder(gridName, layerIds, isTrial)
 * Reorders grid members to match the given ID array
 * (called after drag-drop in the panel).
 */
function gridReorder(gridName, layerIds, isTrial) {
  var comp = getActiveComp();
  if (!comp) return;

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) return;

  app.beginUndoGroup("Grid Builder: Reorder");
  try {
    var meta = readGridMeta(nullLayer);

    // Rebuild members in new order
    var idToMember = {};
    for (var i = 0; i < meta.members.length; i++) {
      idToMember[meta.members[i].id] = meta.members[i];
    }
    var newMembers = [];
    for (var j = 0; j < layerIds.length; j++) {
      var id = String(layerIds[j]);
      if (idToMember[id]) newMembers.push(idToMember[id]);
    }
    meta.members = newMembers;

    writeGridMeta(nullLayer, meta);
    rebuildAllExpressions(comp, nullLayer, meta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error reordering: " + e.toString());
  }
}

/**
 * gridRemove(gridName)
 * Removes a grid: deletes the Null, clears all member expressions.
 */
function gridRemove(gridName) {
  var comp = getActiveComp();
  if (!comp) return;

  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) { aeAlert("Grid '" + gridName + "' not found."); return; }

  app.beginUndoGroup("Grid Builder: Remove Grid");
  try {
    var meta = readGridMeta(nullLayer);
    for (var i = 0; i < meta.members.length; i++) {
      var layer = findLayerById(comp, meta.members[i].id);
      if (layer) clearExpressionsFromMember(layer);
    }
    nullLayer.remove();
    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error removing grid: " + e.toString());
  }
}

/**
 * gridRemoveAll()
 * Removes ALL grids from the active composition.
 */
function gridRemoveAll() {
  var comp = getActiveComp();
  if (!comp) return;

  var nulls = getAllGridNulls(comp);
  if (nulls.length === 0) { aeAlert("No grids found in this composition."); return; }

  app.beginUndoGroup("Grid Builder: Remove All Grids");
  try {
    for (var i = 0; i < nulls.length; i++) {
      var meta = nulls[i].meta;
      for (var j = 0; j < meta.members.length; j++) {
        var layer = findLayerById(comp, meta.members[j].id);
        if (layer) clearExpressionsFromMember(layer);
      }
      nulls[i].layer.remove();
    }
    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error removing all grids: " + e.toString());
  }
}

/**
 * gridDuplicate(gridName)
 * Duplicates a grid's Null and re-applies it to the same layers
 * under a new name — useful for trying different settings.
 */
function gridDuplicate(gridName) {
  var comp = getActiveComp();
  if (!comp) return;

  var srcNull = findGridNull(comp, gridName);
  if (!srcNull) { aeAlert("Grid '" + gridName + "' not found."); return; }

  app.beginUndoGroup("Grid Builder: Duplicate Grid");
  try {
    var srcMeta = readGridMeta(srcNull);

    // Duplicate the Null layer
    var newNull = srcNull.duplicate();
    var newName = gridName + "_copy";
    // Ensure unique name
    var idx = 1;
    while (findGridNull(comp, newName + (idx > 1 ? "_" + idx : ""))) idx++;
    if (idx > 1) newName = newName + "_" + idx;
    newNull.name = GB_TAG + newName;

    // Clone meta with new name
    var newMeta = { name: newName, mode: srcMeta.mode, members: srcMeta.members.slice() };
    writeGridMeta(newNull, newMeta);

    app.endUndoGroup();
  } catch(e) {
    app.endUndoGroup();
    aeAlert("Error duplicating grid: " + e.toString());
  }
}

/**
 * removeAllTargets(gridName)
 * Convenience alias for gridRemoveLayers with all members.
 */
function removeAllTargets(gridName) {
  var comp = getActiveComp();
  if (!comp) return;
  var nullLayer = findGridNull(comp, gridName);
  if (!nullLayer) return;
  var meta = readGridMeta(nullLayer);
  var ids  = [];
  for (var i = 0; i < meta.members.length; i++) ids.push(meta.members[i].id);
  gridRemoveLayers(gridName, ids, false);
}
