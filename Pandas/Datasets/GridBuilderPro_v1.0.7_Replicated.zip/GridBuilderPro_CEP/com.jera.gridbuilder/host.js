/**
 * Grid Builder Pro — CEP Panel JavaScript (host.js)
 * Communicates with After Effects via evalScript → jsx/host.jsx
 *
 * Replicated from com.jera.gridbuilder v1.0.7 (deobfuscated)
 * Original by Sebastian Jelic and Rico Rambo — all rights reserved.
 * This reconstruction is for educational/archival use only.
 */

// ─── AE label colours (index 0–16 matches AE label order) ───
const aeColors = [
  '#b5b5b5', // 0  None/grey
  '#b53838', // 1  Red
  '#e6d758', // 2  Yellow
  '#38b58f', // 3  Aqua
  '#8a5838', // 4  Pink (brown)
  '#8a38e6', // 5  Lavender
  '#e6a078', // 6  Peach
  '#78c8a0', // 7  Sea Foam
  '#388ce6', // 8  Blue
  '#e6a0c8', // 9  Magenta
  '#3ce6e6', // 10 Cyan
  '#e67838', // 11 Tangerine
  '#b53838', // 12 Mango (reuse)
  '#e63ce6', // 13 Orchid
  '#3ce63c', // 14 Electric Green
  '#8a8a58', // 15 Olive
  '#388a58'  // 16 Teal
];

// ─── Extension path (used to locate .ffx preset files) ──────
var rawPath   = window.__adobe_cep__.getSystemPath('extension');
var extPath   = decodeURI(rawPath).replace(/\\/g, '/');
// Handle Adobe's internal "DocumentsResources" path rewriting
if (extPath.indexOf('.app/Contents/Resources/') > -1) {
  var parts = extPath.split('.app/Contents/Resources/');
  extPath = parts[0];
  if (extPath.charAt(0) !== '/') extPath = '/' + extPath;
}

// ─── In-memory grid store ────────────────────────────────────
var gridsData = [];

// ─── CEP → ExtendScript bridge ──────────────────────────────
function jsx(script, callback) {
  try {
    window.__adobe_cep__.evalScript(script, callback || function(){});
  } catch (e) {
    alert('CEP Error: ' + e.toString());
  }
}

// Trigger an alert dialog inside After Effects (for user-facing errors)
function triggerAeAlert(msg) {
  var safe = msg.replace(/"/g, '\\"').replace(/'/g, "\\'");
  jsx('aeAlert("' + safe + '")');
}

// ─── Read the current "Mode" dropdown value ──────────────────
function getM() {
  return document.getElementById('mode').value;
}

// ─── Load all grids from AE, refresh the UI ─────────────────
function loadGrids() {
  jsx('getGridsData()', function(result) {
    try {
      gridsData = JSON.parse(result);
      populateUI();
    } catch (e) {
      console.log('Failed to parse grid data', e);
    }
  });
}

// ─── Populate the gridSelect dropdown + layer list ──────────
function populateUI() {
  var sel = document.getElementById('gridSelect');
  var prevVal = sel.value !== '' ? parseInt(sel.value) : -1;
  sel.innerHTML = '';

  if (gridsData.length === 0) {
    sel.innerHTML = '<option value="">No Grids Found</option>';
    document.getElementById('layerList').innerHTML = '';
    return;
  }

  gridsData.forEach(function(grid, idx) {
    var opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = grid.gridName;
    sel.appendChild(opt);
  });

  // Restore previous selection if still valid
  if (prevVal >= gridsData.length) prevVal = -1;
  sel.value = prevVal;
  renderLayers(prevVal);
}

// ─── Render the layer list for a given grid index ───────────
function renderLayers(gridIdx) {
  var layerList = document.getElementById('layerList');
  layerList.innerHTML = '';

  // Also sync the gridSelect value
  var gridSel = document.getElementById('gridSelect');
  var grid = gridsData[gridIdx];
  if (!grid) return;
  if (gridSel && grid.gridName !== undefined) gridSel.value = gridIdx;

  grid.layers.forEach(function(layer) {
    var color = aeColors[layer.label] || '#b5b5b5';
    var li = document.createElement('li');
    li.className = 'layer-item';
    li.draggable = true;
    li.setAttribute('data-id', layer.id);
    li.innerHTML =
      '<span class="drag-handle">≡</span>' +
      '<span class="layer-color" style="background-color: ' + color + ';"></span>' +
      '<span class="layer-name">' + layer.name + '</span>' +
      '<span class="delete-item" title="Remove from grid">&times;</span>';
    layerList.appendChild(li);
  });
}

// ════════════════════════════════════════════════════════════
//  EVENT WIRING
// ════════════════════════════════════════════════════════════

// ── gridSelect change → re-render layers ───────────────────
document.getElementById('gridSelect').addEventListener('change', function(e) {
  renderLayers(e.target.value);
});

// ── Create Grid ────────────────────────────────────────────
document.getElementById('btnCreate').addEventListener('click', function() {
  // gridCreate(mode, "extPath", isTrial)
  jsx('gridCreate(' + getM() + ', "' + extPath + '", false)', loadGrids);
});

// ── Change Mode (update existing grid's type) ───────────────
document.getElementById('btnChangeMode').addEventListener('click', function() {
  var gridIdx  = document.getElementById('gridSelect').value;
  var newMode  = document.getElementById('updateMode').value;
  if (gridIdx !== '' && gridsData[gridIdx]) {
    var gridName = gridsData[gridIdx].gridName;
    // gridUpdate(mode, "extPath", "gridName", isTrial)
    jsx('gridUpdate(' + newMode + ', "' + extPath + '", "' + gridName + '", false)', loadGrids);
  }
});

// ── Add Selected Layer(s) to Grid ──────────────────────────
document.getElementById('btnAdd').addEventListener('click', function() {
  var gridIdx = document.getElementById('gridSelect').value;
  if (gridIdx !== '' && gridsData[gridIdx]) {
    var gridName = gridsData[gridIdx].gridName;
    // gridAdd("gridName", "extPath", isTrial)
    jsx('gridAdd("' + gridName + '", "' + extPath + '", false)', loadGrids);
  } else {
    // No grid selected — create one first using selected layers as seed
    jsx('gridAdd(undefined, "' + extPath + '", false)', loadGrids);
  }
});

// ── Replace (swap selected layers into highlighted positions) -
document.getElementById('btnReplace').addEventListener('click', function() {
  var gridIdx = document.getElementById('gridSelect').value;
  if (gridIdx === '') return;
  var gridName  = gridsData[gridIdx].gridName;
  var selected  = layerList.querySelectorAll('.layer-item.selected');
  if (selected.length === 0) {
    triggerAeAlert('Please select at least one layer in the panel to replace.');
    return;
  }
  var ids = [];
  selected.forEach(function(el) { ids.push(el.getAttribute('data-id')); });
  // gridReplace("gridName", ids, isTrial)
  jsx('gridReplace("' + gridName + '", [' + ids.join(',') + '], false)', loadGrids);
});

// ── Remove Grid ────────────────────────────────────────────
document.getElementById('btnRemoveGrid').addEventListener('click', function() {
  var gridIdx = document.getElementById('gridSelect').value;
  if (gridIdx !== '' && gridsData[gridIdx]) {
    var gridName = gridsData[gridIdx].gridName;
    jsx('gridRemove("' + gridName + '")', loadGrids);
  } else {
    jsx('gridRemoveAll()', loadGrids);
  }
});

// ── Duplicate Grid ─────────────────────────────────────────
document.getElementById('btnDuplicateGrid').addEventListener('click', function() {
  var gridIdx = document.getElementById('gridSelect').value;
  if (!gridsData[gridIdx]) return;
  var gridName = gridsData[gridIdx].gridName;
  // gridDuplicate("gridName")
  jsx('gridDuplicate("' + gridName + '")', loadGrids);
});

// ── Refresh grid list ───────────────────────────────────────
document.getElementById('btnRefreshGrids').addEventListener('click', loadGrids);

// ════════════════════════════════════════════════════════════
//  LAYER LIST INTERACTIONS
// ════════════════════════════════════════════════════════════
const layerList = document.getElementById('layerList');

var lastSelectedLayer = null;

// ── Click: select / delete ─────────────────────────────────
layerList.addEventListener('click', function(e) {
  // Delete button
  if (e.target.classList.contains('delete-item')) {
    e.stopPropagation();
    var li       = e.target.closest('.layer-item');
    var gridIdx  = document.getElementById('gridSelect').value;
    if (!gridsData[gridIdx]) return;
    var gridName = gridsData[gridIdx].gridName;

    var ids = [];
    if (li.classList.contains('selected')) {
      // Delete all selected items
      var allSel = layerList.querySelectorAll('.layer-item.selected');
      if (allSel.length > 1) {
        allSel.forEach(function(el) { ids.push(el.getAttribute('data-id')); });
      } else {
        ids.push(li.getAttribute('data-id'));
      }
    } else {
      ids.push(li.getAttribute('data-id'));
    }
    // gridRemoveLayers("gridName", [ids], isTrial)
    jsx('gridRemoveLayers("' + gridName + '", [' + ids.join(',') + '], false)', loadGrids);
    return;
  }

  // Layer item click → selection logic
  if (e.target.tagName !== 'INPUT') {
    var li = e.target.closest('.layer-item');
    if (li) {
      var isCtrl  = e.ctrlKey || e.metaKey;
      var isShift = e.shiftKey;
      if (isShift) window.getSelection().removeAllRanges();

      if (isShift && lastSelectedLayer) {
        // Range select
        var allItems = Array.prototype.slice.call(layerList.querySelectorAll('.layer-item'));
        allItems.forEach(function(el) { el.classList.remove('selected'); });
        var a = allItems.indexOf(lastSelectedLayer);
        var b = allItems.indexOf(li);
        var lo = Math.min(a, b), hi = Math.max(a, b);
        for (var i = lo; i <= hi; i++) { allItems[i].classList.add('selected'); }
      } else if (isCtrl) {
        li.classList.toggle('selected');
        lastSelectedLayer = li;
      } else {
        // Single select
        layerList.querySelectorAll('.layer-item').forEach(function(el) {
          el.classList.remove('selected');
        });
        li.classList.add('selected');
        lastSelectedLayer = li;
      }
    }
  }
});

// ── Drag: start ────────────────────────────────────────────
layerList.addEventListener('dragstart', function(e) {
  if (e.target.classList.contains('layer-item')) {
    e.target.classList.add('dragging');
  }
});

// ── Drag: end — reorder and sync to AE ─────────────────────
layerList.addEventListener('dragend', function(e) {
  if (e.target.classList.contains('layer-item')) {
    e.target.classList.remove('dragging');

    // Collect new order
    var items = layerList.querySelectorAll('.layer-item');
    var ids   = [];
    items.forEach(function(el) { ids.push(el.getAttribute('data-id')); });

    var gridIdx = document.getElementById('gridSelect').value;
    if (!gridsData[gridIdx]) return;
    var gridName = gridsData[gridIdx].gridName;

    // gridReorder("gridName", [ids], isTrial)
    jsx('gridReorder("' + gridName + '", [' + ids.join(',') + '], false)', loadGrids);
  }
});

// ── Drag: over — live re-ordering ─────────────────────────
layerList.addEventListener('dragover', function(e) {
  e.preventDefault();
  var afterEl  = getDragAfterElement(layerList, e.clientY);
  var dragging = document.querySelector('.dragging');
  if (afterEl == null) {
    layerList.appendChild(dragging);
  } else {
    layerList.insertBefore(dragging, afterEl);
  }
});

/** Find the element after which the dragged item should be inserted */
function getDragAfterElement(container, y) {
  var draggableEls = [...container.querySelectorAll('.layer-item:not(.dragging)')];
  return draggableEls.reduce(function(closest, el) {
    var box    = el.getBoundingClientRect();
    var offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) {
      return { offset: offset, element: el };
    } else {
      return closest;
    }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

// ════════════════════════════════════════════════════════════
//  INIT
// ════════════════════════════════════════════════════════════
setTimeout(loadGrids, 0);
